# **App Name**: FitGenie

## Core Features:

- Workout Plan Generation: AI-powered workout plan generator that suggests exercises based on user goals and fitness level using a reasoning tool. Considers available equipment, time constraints and user preferences to suggest modifications to workouts.
- Nutrition Plan Generation: AI-driven nutrition plan generator suggesting meal plans tailored to dietary restrictions and preferences. Suggests alternatives based on a reasoning tool.
- Workout Display: Display workout steps in an easy-to-follow format.
- Nutrition Plan Display: Nutritional plan with recipes and macros. Allow saving and sharing recipes. Users should be able to replace specific meals/ingredients with alternative suggestions.
- Progress Tracking: Profile that allows users to track fitness metrics (weight, reps, etc), upload photos, journal entries, track steps via healthkit

## Style Guidelines:

- Primary color: Strong orange (#E97451) for energy and activity. Orange will reflect the movement and calorie burn.
- Background color: Light, desaturated orange (#F8E9E4).
- Accent color: A lighter, brighter pink (#F2A7A7) complements the primary color for call to actions, creating visual interest.
- Clean and readable sans-serif fonts.
- Modern and minimalist icons.
- Clear and structured layout.